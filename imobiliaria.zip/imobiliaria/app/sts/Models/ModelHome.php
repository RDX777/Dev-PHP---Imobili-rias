<?php

namespace Sts\Models;

class ModelHome {

    public function index() {
        include 'app/sts/Views/ViewHome.php';
    }

}
    